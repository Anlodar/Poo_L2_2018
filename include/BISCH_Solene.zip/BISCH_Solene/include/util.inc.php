<?php
	// La fonction dateCreate retourne la date du jour, le mois et l'année. Cette date est donnée en français(fr paramètre donner par défaut) ou en anglais (n'importe quel autre mot passer en paramètre)
 	function dateCreate($langue){
 		$joursFr = array('Lundi','Mardi','Mercredi','Jeudi','Vendredi','Samedi','Dimanche');
		$joursEn = array('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday');
		$moisFr= array('Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Aout','Septembre','Octobre','Novembre','Décembre');
		$moisEn = array('January','February','March','April','May','June','July','August','September','October','November','December');

		$jour = date('N');
		$mois = date('m');
		$annee = date('Y');

		if ($langue == 'fr'){
			return $joursFr[$jour-1] . ' ' . $jour . ' ' . $moisFr[$mois-1] . ' ' . $annee;
		}
		else{
			return $joursEn[$jour-1] . ', ' . $moisEn[$mois-1] . ' ' . $jour . ', ' .  ' ' . $annee;
		}

 	}

 	//donneURL donne les composants (protocole, TLD, nom de la machine) du lien internet passer en argument
 	function donneURL($lienURL){
 		return ('Le protocole est le suivant: ' . explode("://",$lienURL)[0] . '<br/>' . 'Le Top Level Domain est le suivant : ' . explode(".",$lienURL)[2] . '<br/>' . 'L organisme est le suivant : ' . explode(".",$lienURL)[1] . '<br/>' . 'Le nom de la machine : ' . explode(".",explode("://",$lienURL)[1])[0] . '<br/>');
 	}

 	/*
 	function calendrierMois() {
 		$joursFr = array('Lun','Ma','Me','Je','Ve','Sa','Di');
		$moisFr= array('Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Aout','Septembre','Octobre','Novembre','Décembre');
		$jour_par_mois = array('31','28','31','30','31','30','31','31','30','31','30','31');

		$jour = date('N');
		$mois = date('m');
		$annee = date('Y');
		$calendrier = "";

	
			$calendrier.= '<table>' . '<tr>' . '<th>' . $moisFr[$mois-1] . '</th>' . '</tr>' . '<tr>' ;
			for($i=0; $i<8; $i++){
				$calendrier .= '<th>' . $joursFr[$i] . '</th>' ;
			}
			$calendrier .= '</tr>';
			return $calendrier;
		
 	}

	*/
?>